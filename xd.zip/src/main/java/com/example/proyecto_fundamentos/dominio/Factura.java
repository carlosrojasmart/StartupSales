package com.example.proyecto_fundamentos.dominio;

import java.util.Date;
import java.util.List;

public class Factura {
    private int numeroFactura;
    private Date fecha;
    private double total;
    private List<Venta> detalleVenta;

    public int getNumeroFactura() {
        return numeroFactura;
    }

    public void setNumeroFactura(int numeroFactura) {
        this.numeroFactura = numeroFactura;
    }

    public List<Venta> getDetalleVenta() {
        return detalleVenta;
    }

    public void setDetalleVenta(List<Venta> detalleVenta) {
        this.detalleVenta = detalleVenta;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
}

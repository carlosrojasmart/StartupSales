module com.example.proyecto_fundamentos {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;

    opens com.example.proyecto_fundamentos to javafx.fxml;
    exports com.example.proyecto_fundamentos;
}